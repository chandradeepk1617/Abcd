import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup } from '@angular/forms';
import { DataService } from '../data.service';
import { Router} from '@angular/router';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
addForm:FormGroup;
  constructor(public fb:FormBuilder,public service1:DataService,public router:Router) { 
    this.addForm = this.fb.group(
      {
        id:[''],
        name:[''],
        salary:[''],
        department:['']
      }
    );
  }

  ngOnInit(): void {
  }
  addData()
  {
    this.service1.addData(this.addForm.value);
    this.router.navigate(['/view'])

  }

}
