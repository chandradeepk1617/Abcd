export class EmployeeObj
{
    id:string;
    name:string;
    salary:string;
    department:string;
}