import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable,throwError} from 'rxjs';
import {EmployeeObj} from './employee';
import {retry,catchError} from  'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  empData:EmployeeObj[]=[];
localUrl = './assets/employee.json';
  constructor(private http:HttpClient) { this.getEmployee();}
getEmployee()
  {
     this.http.get<EmployeeObj>(this.localUrl).subscribe((data:any)=>
     {
       this.empData=data;
     });
     //return this.empData;
   
  }
  deleteData(emp2:EmployeeObj)
  {
    const index=this.empData.findIndex(item=>item.id===emp2.id)
    this.empData.splice(index,1);
  }
  addData(emp3:EmployeeObj)
  {
    this.empData.push(emp3);
  }
}