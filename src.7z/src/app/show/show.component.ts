import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { EmployeeObj } from '../employee';
import { FormBuilder,FormGroup} from '@angular/forms';

@Component({
  selector: 'app-show',
  templateUrl: './show.component.html',
  styleUrls: ['./show.component.css']
})
export class ShowComponent implements OnInit {
  empdata1:EmployeeObj[]=[];
  addForm:FormGroup;

  constructor(public service1:DataService,public fb:FormBuilder) {
this.addForm = this.fb.group(
  {
    id:[''],
    name:[''],
    salary:[''],
    department:['']
  }
);
    
  }

  ngOnInit(): void {

  }
  getData()
  {
    this.empdata1=this.service1.empData;
  }
  delete(emp1:EmployeeObj)
  {
    
    this.service1.deleteData(emp1);
  }
  
}
